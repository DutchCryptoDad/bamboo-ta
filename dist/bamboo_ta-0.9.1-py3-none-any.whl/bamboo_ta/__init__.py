# -*- coding: utf-8 -*-
from bamboo_ta.bamboo_ta import *
import numpy as np
from pandas import DataFrame
import pandas as pd

name = "bamboo_ta"
"""
.. moduleauthor:: DutchCryptoDad
"""
