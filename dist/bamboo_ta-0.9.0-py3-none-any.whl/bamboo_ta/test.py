import bamboo_ta as bta
dir(bta)
