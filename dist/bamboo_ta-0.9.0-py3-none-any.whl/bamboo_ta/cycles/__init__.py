# -*- coding: utf-8 -*-
# cycles/__init__.py

from .even_better_sinewave import even_better_sinewave